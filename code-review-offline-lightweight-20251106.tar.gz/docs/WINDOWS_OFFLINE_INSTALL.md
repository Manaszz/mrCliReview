# Установка на изолированном Windows PC

Руководство по установке AI Code Review System на изолированный Windows компьютер без доступа в интернет.

---

## 📋 Требования

### Минимальные требования
- Windows 10/11 Pro или Enterprise (64-bit)
- 4GB RAM (рекомендуется 8GB+)
- 20GB свободного места на диске
- Docker Desktop для Windows

### Предустановленное ПО (ОБЯЗАТЕЛЬНО)
⚠️ **Установите ДО переноса на изолированный ПК (требуется интернет):**

1. **Docker Desktop для Windows**
   - Скачать: https://www.docker.com/products/docker-desktop
   - Версия: 4.25.0 или новее
   - Требует WSL 2 (Windows Subsystem for Linux)
   
2. **PowerShell 7+** (опционально, но рекомендуется)
   - Скачать: https://github.com/PowerShell/PowerShell/releases
   - Версия: 7.3 или новее

3. **7-Zip или WinRAR** для распаковки архивов
   - 7-Zip: https://www.7-zip.org/

---

## 🚀 Быстрая установка (5 минут)

### Шаг 1: Перенос файлов

Скопируйте файл `code-review-offline-YYYYMMDD.tar.gz` на изолированный Windows ПК:

**Вариант A: USB флешка**
```
1. Вставьте USB флешку
2. Скопируйте файл на флешку
3. Перенесите на целевой ПК
```

**Вариант B: Внутренняя система передачи файлов**
```
Используйте корпоративную систему передачи файлов
```

### Шаг 2: Распаковка

1. Щелкните правой кнопкой по архиву
2. Выберите "7-Zip → Извлечь в 'code-review-offline...'"
3. Откройте распакованную папку

Или через командную строку:
```cmd
7z x code-review-offline-20251106.tar.gz
7z x code-review-offline-20251106.tar
cd code-review-offline-20251106
```

### Шаг 3: Запуск установки

**Откройте PowerShell от имени администратора:**

1. Нажмите `Win + X`
2. Выберите "Windows PowerShell (администратор)"
3. Перейдите в папку с пакетом:

```powershell
cd C:\путь\к\code-review-offline-20251106
```

4. Запустите скрипт установки:

```powershell
.\install-windows.ps1
```

**Что делает скрипт:**
- ✅ Проверяет наличие Docker Desktop
- ✅ Загружает Docker образы в систему
- ✅ Создает файл конфигурации .env
- ✅ Открывает .env в Notepad для редактирования

### Шаг 4: Настройка конфигурации

Отредактируйте файл `.env` (откроется автоматически в Notepad):

```env
# ОБЯЗАТЕЛЬНЫЕ ПАРАМЕТРЫ - заполните перед запуском!

# URL внутреннего Model API (DeepSeek/Qwen)
MODEL_API_URL=http://internal-model-api.company.local:8000/v1

# API ключ для Model API
MODEL_API_KEY=your-internal-api-key-here

# URL внутреннего GitLab
GITLAB_URL=https://gitlab.company.local

# GitLab Personal Access Token
GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx

# Имена моделей (должны быть доступны в вашем Model API)
DEEPSEEK_MODEL_NAME=deepseek-v3.1-terminus
QWEN3_MODEL_NAME=qwen3-coder-32b

# Выбор CLI агента (CLINE или QWEN_CODE)
DEFAULT_CLI_AGENT=CLINE

# Настройки логирования
LOG_LEVEL=INFO
```

**Сохраните файл** (Ctrl+S) и закройте Notepad.

### Шаг 5: Запуск системы

```powershell
# Запустить Docker Compose
docker-compose -f docker-compose.offline.yml up -d

# Проверить статус
docker-compose ps

# Посмотреть логи
docker-compose logs -f
```

### Шаг 6: Проверка работы

Откройте браузер и перейдите:
```
http://localhost:8000/api/v1/health
```

Ожидаемый ответ:
```json
{
  "status": "healthy",
  "cline_available": true,
  "qwen_available": true,
  "model_api_connected": true,
  "gitlab_connected": true
}
```

---

## 📝 Ручная установка (альтернативный метод)

Если автоматический скрипт не работает:

### 1. Проверить Docker Desktop

```powershell
# Проверить, что Docker Desktop запущен
docker --version
docker ps
```

Если Docker не запущен:
- Откройте Docker Desktop из меню Пуск
- Дождитесь запуска (зеленая иконка в трее)

### 2. Загрузить Docker образы вручную

```powershell
# Загрузить базовый образ
docker load -i base-python-nodejs.tar

# Загрузить образ API
docker load -i code-review-api.tar

# Проверить загруженные образы
docker images
```

Вы должны увидеть:
```
REPOSITORY                                TAG        IMAGE ID       SIZE
code-review-api                           latest     xxxxxxxxxxxx   2.5GB
nikolaik/python-nodejs                    python...  xxxxxxxxxxxx   450MB
```

### 3. Создать конфигурацию

```powershell
# Скопировать пример конфигурации
Copy-Item .env.example .env

# Отредактировать в Notepad
notepad .env
```

### 4. Запустить систему

```powershell
docker-compose -f docker-compose.offline.yml up -d
```

---

## 🔧 Troubleshooting

### Проблема 1: Docker Desktop не запускается

**Симптомы:**
```
error during connect: This error may indicate that the docker daemon is not running
```

**Решение:**
1. Откройте Docker Desktop из меню Пуск
2. Дождитесь полного запуска (зеленая иконка)
3. Проверьте: Settings → General → "Use WSL 2 based engine" должен быть включен

### Проблема 2: WSL 2 не установлен

**Симптомы:**
```
WSL 2 installation is incomplete
```

**Решение:**
```powershell
# Запустите в PowerShell от администратора
wsl --install
wsl --set-default-version 2

# Перезагрузите компьютер
```

### Проблема 3: Недостаточно памяти

**Симптомы:**
```
Error: Container killed (out of memory)
```

**Решение:**
1. Откройте Docker Desktop
2. Settings → Resources → Memory
3. Увеличьте до 8GB (если возможно)
4. Apply & Restart

### Проблема 4: Порт 8000 уже занят

**Симптомы:**
```
Error: Port 8000 is already allocated
```

**Решение:**

Вариант A: Остановить процесс на порту 8000
```powershell
# Найти процесс
netstat -ano | findstr :8000

# Остановить процесс (замените PID на актуальный)
taskkill /PID 12345 /F
```

Вариант B: Изменить порт в docker-compose.offline.yml
```yaml
ports:
  - "8001:8000"  # Изменить 8000 на 8001
```

### Проблема 5: CLI не найден в контейнере

**Симптомы:**
```
"cline_available": false
```

**Решение:**
```powershell
# Войти в контейнер
docker exec -it code-review-api bash

# Проверить CLI
which cline
cline --version

# Если не найден - проверить offline-packages
ls /tmp/npm-packages/
```

### Проблема 6: Не удается подключиться к Model API

**Симптомы:**
```
"model_api_connected": false
```

**Решение:**
1. Проверьте MODEL_API_URL в .env
2. Убедитесь, что URL доступен изнутри Docker:

```powershell
docker exec -it code-review-api curl MODEL_API_URL/v1/models
```

3. Если используется `localhost`, замените на IP адрес хоста:
   - Windows: `host.docker.internal`
   - Пример: `http://host.docker.internal:8000/v1`

### Проблема 7: Не удается подключиться к GitLab

**Симптомы:**
```
"gitlab_connected": false
```

**Решение:**
1. Проверьте GITLAB_URL и GITLAB_TOKEN в .env
2. Проверьте токен:

```powershell
# Из PowerShell на хосте
$headers = @{"Private-Token"="your-token-here"}
Invoke-RestMethod -Uri "https://gitlab.company.local/api/v4/user" -Headers $headers
```

3. Убедитесь, что токен имеет права:
   - `read_repository`
   - `write_repository`
   - `api`

---

## 🔄 Обновление системы

### Обновление до новой версии

```powershell
# Остановить текущую версию
docker-compose down

# Загрузить новый образ
docker load -i code-review-api-new.tar

# Запустить новую версию
docker-compose -f docker-compose.offline.yml up -d
```

### Обновление конфигурации

```powershell
# Остановить систему
docker-compose down

# Отредактировать .env
notepad .env

# Перезапустить
docker-compose -f docker-compose.offline.yml up -d
```

---

## 📊 Мониторинг и логи

### Просмотр логов

```powershell
# Все логи
docker-compose logs

# Последние 100 строк
docker-compose logs --tail=100

# В реальном времени
docker-compose logs -f

# Только определенный сервис
docker-compose logs review-api
```

### Проверка ресурсов

```powershell
# Использование ресурсов
docker stats

# Информация о контейнере
docker inspect code-review-api
```

### Проверка работы API

```powershell
# Health check
curl http://localhost:8000/api/v1/health

# Service info
curl http://localhost:8000/

# Тестовый review (замените на реальные данные)
$body = @{
    project_id = 123
    merge_request_iid = 456
    review_types = @("ERROR_DETECTION")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8000/api/v1/review" `
    -Method POST `
    -Body $body `
    -ContentType "application/json"
```

---

## 🛑 Остановка и удаление

### Остановка системы

```powershell
# Остановить контейнеры
docker-compose down

# Остановить и удалить volumes
docker-compose down -v
```

### Полное удаление

```powershell
# Остановить и удалить всё
docker-compose down -v --rmi all

# Очистить неиспользуемые образы
docker system prune -a
```

---

## 📚 Дополнительные ресурсы

### Документация

- **README.md** - Полное описание системы
- **OFFLINE_QUICK_START.md** - Краткое руководство
- **.env.example** - Аннотированная конфигурация

### Структура файлов

```
code-review-offline-20251106/
├── base-python-nodejs.tar      # Базовый Docker образ
├── code-review-api.tar         # Образ системы ревью
├── offline-packages/           # npm и pip пакеты
│   ├── cline-cli-*.tgz
│   ├── qwen-code-*.tgz
│   └── pip/                    # Python зависимости
├── app/                        # Исходный код
├── prompts/                    # Промпты для AI
├── rules/                      # Правила ревью
├── docker-compose.offline.yml  # Docker Compose конфигурация
├── Dockerfile.offline          # Dockerfile для сборки
├── .env.example                # Пример конфигурации
├── install-windows.ps1         # Скрипт установки для Windows
├── install-linux.sh            # Скрипт установки для Linux
└── INSTALL_README.txt          # Это руководство
```

---

## 💡 Советы и рекомендации

### Производительность

1. **Выделите достаточно ресурсов Docker Desktop:**
   - Минимум 4GB RAM, рекомендуется 8GB
   - 4 CPU cores

2. **Используйте SSD для лучшей производительности**

3. **Отключите антивирус для папки с Docker** (если разрешено политикой)

### Безопасность

1. **Храните .env в безопасном месте**
   - Не коммитьте в Git
   - Ограничьте доступ к файлу

2. **Регулярно обновляйте токены GitLab**
   - Рекомендуется каждые 90 дней

3. **Используйте HTTPS для Model API и GitLab**

### Резервное копирование

```powershell
# Создать backup конфигурации
$timestamp = Get-Date -Format "yyyyMMdd"
Compress-Archive -Path .env,docker-compose.offline.yml `
    -DestinationPath "backup-config-$timestamp.zip"
```

---

**Версия документа:** 1.0  
**Дата обновления:** 2025-11-06  
**Совместимость:** Windows 10/11, Docker Desktop 4.25+
