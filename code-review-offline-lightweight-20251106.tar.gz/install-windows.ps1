# AI Code Review System - Установка (Windows)

Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "  AI Code Review System - Установка (Windows)"
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""

$dockerExists = Get-Command docker -ErrorAction SilentlyContinue
if (-not $dockerExists) {
    Write-Host "❌ Docker Desktop не найден" -ForegroundColor Red
    Write-Host "Установите Docker Desktop:" -ForegroundColor Yellow
    Write-Host "  https://www.docker.com/products/docker-desktop"
    exit 1
}

Write-Host "✅ Docker Desktop найден" -ForegroundColor Green
Write-Host ""

Write-Host "📦 Сборка Docker образов..." -ForegroundColor Yellow
Write-Host "ВАЖНО: Это может занять 10-15 минут" -ForegroundColor Yellow
Write-Host ""

# Загрузить или скачать базовый образ
if (Test-Path base-python-nodejs.tar) {
    Write-Host "  → Загрузка базового образа из архива..." -ForegroundColor Yellow
    docker load -i base-python-nodejs.tar
} else {
    Write-Host "  → Скачивание базового образа..." -ForegroundColor Yellow
    docker pull nikolaik/python-nodejs:python3.11-nodejs18-slim
}

# Собрать API образ
Write-Host "  → Сборка code-review-api..." -ForegroundColor Yellow
docker-compose -f docker-compose.offline.yml build

if (-not (Test-Path .env)) {
    Write-Host ""
    Write-Host "⚙️  Создание .env файла..." -ForegroundColor Yellow
    Copy-Item .env.example .env
    Write-Host "❗ ВАЖНО: Отредактируйте .env файл" -ForegroundColor Red
    Write-Host ""
    Write-Host "Требуемые параметры:" -ForegroundColor Yellow
    Write-Host "  - MODEL_API_URL"
    Write-Host "  - MODEL_API_KEY"
    Write-Host "  - GITLAB_URL"
    Write-Host "  - GITLAB_TOKEN"
    Write-Host ""
    notepad.exe .env
}

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "✅ Установка завершена!" -ForegroundColor Green
Write-Host ""
Write-Host "Следующие шаги:" -ForegroundColor Yellow
Write-Host "  1. Отредактируйте .env (открыт в Notepad)"
Write-Host "  2. Запустите: docker-compose -f docker-compose.offline.yml up -d"
Write-Host "  3. Проверьте: curl http://localhost:8000/api/v1/health"
Write-Host "===================================================================" -ForegroundColor Cyan
