# 📦 AI Code Review System - Offline Deployment Package

> Полный пакет для развертывания системы автоматического code review с Cline CLI в изолированной среде без доступа в интернет.

---

## 🎯 Что это?

Этот пакет содержит всё необходимое для установки и запуска AI Code Review System в полностью офлайн режиме:

- ✅ Docker образы с предустановленным Cline CLI и Qwen Code CLI
- ✅ Все Python и npm зависимости
- ✅ Исходный код приложения
- ✅ Промпты и правила для ревью
- ✅ Автоматические скрипты установки для Windows и Linux
- ✅ Детальная документация

---

## 📋 Содержимое пакета

```
code-review-offline-YYYYMMDD/
│
├── 🐳 Docker образы
│   ├── base-python-nodejs.tar     # Базовый образ (Python 3.11 + Node.js 18)
│   └── code-review-api.tar        # Образ системы с Cline CLI
│
├── 📦 Зависимости
│   └── offline-packages/
│       ├── cline-cli-*.tgz        # Cline CLI для npm
│       ├── qwen-code-*.tgz        # Qwen Code CLI для npm
│       └── pip/                   # Python пакеты (FastAPI, httpx, etc.)
│
├── 💻 Исходный код
│   ├── app/                       # FastAPI приложение
│   ├── prompts/                   # Промпты для AI агентов
│   ├── rules/                     # Правила code review
│   └── requirements.txt           # Python зависимости
│
├── ⚙️ Конфигурация
│   ├── docker-compose.offline.yml # Docker Compose конфигурация
│   ├── Dockerfile.offline         # Dockerfile для offline сборки
│   └── .env.example               # Пример настроек
│
├── 🚀 Скрипты установки
│   ├── install-linux.sh           # Автоустановка для Linux/VPS
│   └── install-windows.ps1        # Автоустановка для Windows
│
└── 📚 Документация
    ├── INSTALL_README.txt         # Краткая инструкция (это файл)
    ├── README.md                  # Полное описание системы
    └── OFFLINE_QUICK_START.md     # Быстрый старт
```

---

## 🚀 Быстрая установка

### Вариант A: Linux / VPS сервер

```bash
# 1. Распакуйте архив
tar -xzf code-review-offline-20251106.tar.gz
cd code-review-offline-20251106

# 2. Запустите установку
bash install-linux.sh

# 3. Настройте конфигурацию
nano .env

# 4. Запустите систему
docker-compose -f docker-compose.offline.yml up -d

# 5. Проверьте работу
curl http://localhost:8000/api/v1/health
```

**Детальная инструкция:** См. `docs/LINUX_VPS_OFFLINE_INSTALL.md`

### Вариант B: Windows PC

```powershell
# 1. Распакуйте архив (7-Zip/WinRAR)
# 2. Откройте PowerShell от имени администратора
# 3. Перейдите в папку

cd C:\path\to\code-review-offline-20251106

# 4. Запустите установку
.\install-windows.ps1

# 5. Настройте .env (откроется автоматически)
# 6. Запустите систему

docker-compose -f docker-compose.offline.yml up -d

# 7. Проверьте работу
curl http://localhost:8000/api/v1/health
```

**Детальная инструкция:** См. `docs/WINDOWS_OFFLINE_INSTALL.md`

---

## 📋 Требования

### Минимальные системные требования

| Компонент | Требование |
|-----------|------------|
| **ОС** | Windows 10/11 Pro/Enterprise или Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+) |
| **RAM** | 4GB минимум, 8GB рекомендуется |
| **Диск** | 20GB свободного места |
| **CPU** | 2 cores минимум, 4 cores рекомендуется |
| **Docker** | Docker 20.10+ и Docker Compose 2.0+ |

### Предустановленное ПО (ОБЯЗАТЕЛЬНО!)

⚠️ **Установите ДО переноса в изолированную среду:**

#### Для Windows:
- Docker Desktop для Windows 4.25+
- WSL 2 (устанавливается с Docker Desktop)
- 7-Zip или WinRAR

#### Для Linux:
- Docker Engine 20.10+
- Docker Compose 2.0+
- Git (для работы системы)

### Инфраструктурные требования

✅ **Должны быть доступны в изолированной сети:**
- Внутренний Model API (OpenAI-compatible) с моделями DeepSeek и/или Qwen
- Внутренний GitLab instance
- DNS разрешение для внутренних сервисов

---

## ⚙️ Настройка конфигурации

Отредактируйте файл `.env` перед запуском:

### Обязательные параметры

```env
# URL внутреннего Model API
MODEL_API_URL=http://internal-model-api.company.local:8000/v1

# API ключ для Model API  
MODEL_API_KEY=your-internal-api-key

# URL внутреннего GitLab
GITLAB_URL=https://gitlab.company.local

# GitLab Personal Access Token
# Требуемые права: read_repository, write_repository, api
GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx
```

### Настройки моделей

```env
# Имена моделей (должны быть доступны в Model API)
DEEPSEEK_MODEL_NAME=deepseek-v3.1-terminus
QWEN3_MODEL_NAME=qwen3-coder-32b

# Какой CLI агент использовать по умолчанию
# CLINE - лучше для комплексного анализа
# QWEN_CODE - быстрее, оптимизирован для code review
DEFAULT_CLI_AGENT=CLINE
```

### Опциональные параметры

```env
# Производительность
CLINE_PARALLEL_TASKS=5        # Параллельные задачи для Cline
QWEN_PARALLEL_TASKS=3         # Параллельные задачи для Qwen
REVIEW_TIMEOUT=300            # Таймаут в секундах

# Логирование
LOG_LEVEL=INFO                # DEBUG | INFO | WARNING | ERROR
```

Полный список параметров см. в `.env.example` с подробными комментариями.

---

## 🔍 Проверка установки

### 1. Проверка здоровья системы

```bash
curl http://localhost:8000/api/v1/health
```

**Ожидаемый ответ:**
```json
{
  "status": "healthy",
  "version": "2.0.0",
  "cline_available": true,
  "qwen_available": true,
  "model_api_connected": true,
  "gitlab_connected": true
}
```

### 2. Проверка CLI в контейнере

```bash
# Linux
docker exec -it code-review-api cline --version
docker exec -it code-review-api qwen-code --version

# Windows PowerShell
docker exec -it code-review-api cline --version
docker exec -it code-review-api qwen-code --version
```

### 3. Проверка логов

```bash
# Последние логи
docker-compose logs --tail=100

# Следить в реальном времени
docker-compose logs -f
```

---

## 🎓 Использование

### API Endpoints

```bash
# Базовая информация
GET http://localhost:8000/

# Health check
GET http://localhost:8000/api/v1/health

# Запуск code review
POST http://localhost:8000/api/v1/review
Content-Type: application/json

{
  "project_id": 123,
  "merge_request_iid": 456,
  "review_types": [
    "ERROR_DETECTION",
    "SECURITY_AUDIT", 
    "BEST_PRACTICES"
  ],
  "cli_agent": "CLINE"
}
```

### Поддерживаемые типы ревью

| Тип | Описание | Приоритет |
|-----|----------|-----------|
| `ERROR_DETECTION` | Поиск ошибок и багов | 🔴 Критический |
| `SECURITY_AUDIT` | Проверка безопасности | 🔴 Критический |
| `BEST_PRACTICES` | Соответствие best practices | 🟡 Важный |
| `UNIT_TEST_COVERAGE` | Генерация unit тестов | 🟡 Важный |
| `REFACTORING` | Предложения по рефакторингу | 🟢 Опциональный |
| `DOCUMENTATION` | Проверка документации | 🟢 Опциональный |
| `PERFORMANCE` | Оптимизация производительности | 🟢 Опциональный |
| `ARCHITECTURE` | Архитектурные проблемы | 🟢 Опциональный |
| `ALL` | Все доступные проверки | - |

---

## 🔧 Troubleshooting

### Проблема: CLI не найден

**Симптомы:**
```json
{"cline_available": false}
```

**Решение:**
```bash
# Войти в контейнер и проверить
docker exec -it code-review-api bash
which cline
ls -la /tmp/npm-packages/

# Переустановить CLI вручную
npm install -g /tmp/npm-packages/cline-*.tgz
```

### Проблема: Не подключается к Model API

**Симптомы:**
```json
{"model_api_connected": false}
```

**Решение:**
1. Проверьте `MODEL_API_URL` в `.env`
2. Проверьте доступность из контейнера:
   ```bash
   docker exec -it code-review-api curl MODEL_API_URL/v1/models
   ```
3. Для `localhost` используйте:
   - Windows: `http://host.docker.internal:8000/v1`
   - Linux: `http://172.17.0.1:8000/v1`

### Проблема: Порт занят

**Симптомы:**
```
Error: Port 8000 is already allocated
```

**Решение:**
```bash
# Linux: найти процесс
sudo lsof -i :8000
sudo kill -9 PID

# Windows PowerShell
Get-Process -Id (Get-NetTCPConnection -LocalPort 8000).OwningProcess
Stop-Process -Id PID -Force

# Или изменить порт в docker-compose.offline.yml
ports:
  - "8001:8000"
```

**Больше решений:** См. детальные инструкции для вашей ОС.

---

## 📊 Размеры и производительность

### Размеры компонентов

| Компонент | Примерный размер |
|-----------|------------------|
| Базовый Docker образ | ~450 MB |
| API Docker образ | ~2.5 GB |
| npm пакеты | ~5 MB |
| Python пакеты | ~80 MB |
| **Итого в архиве** | **~2-3 GB** |
| **Распакованный** | **~5-6 GB** |

### Производительность

| Метрика | Значение |
|---------|----------|
| Среднее время ревью | 3-5 минут |
| Параллельные ревью | 5-10 одновременно |
| Поддерживаемый размер MR | До 10,000 строк |
| Throughput (3 pods) | ~100 ревью/час |

---

## 🔄 Обновление

### Обновление до новой версии

```bash
# Остановить текущую версию
docker-compose down

# Загрузить новый образ
docker load -i code-review-api-new.tar

# Запустить
docker-compose -f docker-compose.offline.yml up -d
```

### Обновление промптов и правил

```bash
# Промпты и правила монтируются как volumes
# Можно обновлять без пересборки образа

cp new-prompts/* prompts/
cp new-rules/* rules/

docker-compose restart
```

---

## 🛡️ Безопасность

### Рекомендации

1. **Защитите .env файл**
   ```bash
   chmod 600 .env  # Linux
   ```

2. **Регулярно обновляйте токены**
   - GitLab токены: каждые 90 дней
   - Model API ключи: согласно политике

3. **Используйте firewall**
   ```bash
   # Linux: разрешить только из внутренней сети
   sudo ufw allow from 10.0.0.0/8 to any port 8000
   ```

4. **Настройте SSL/TLS** для production
   - Используйте reverse proxy (nginx)
   - Установите SSL сертификаты

---

## 📚 Документация

### Включено в пакет

| Документ | Описание |
|----------|----------|
| `INSTALL_README.txt` | Краткая инструкция (этот файл) |
| `README.md` | Полное описание системы |
| `OFFLINE_QUICK_START.md` | Быстрый старт для offline установки |
| `.env.example` | Аннотированная конфигурация |
| `docs/WINDOWS_OFFLINE_INSTALL.md` | Детальная инструкция для Windows |
| `docs/LINUX_VPS_OFFLINE_INSTALL.md` | Детальная инструкция для Linux VPS |

### Онлайн документация

См. полную документацию в основном репозитории:
- Архитектура системы
- API документация
- Кастомизация правил
- Интеграция с n8n

---

## 🆘 Получение помощи

### Диагностика проблем

```bash
# Сбор информации для поддержки
cat > diagnostic-info.txt << EOF
=== System Info ===
$(uname -a)
$(free -h)
$(df -h)

=== Docker Info ===
$(docker --version)
$(docker-compose --version)
$(docker ps)
$(docker images)

=== Service Health ===
$(curl -s http://localhost:8000/api/v1/health)

=== Recent Logs ===
$(docker-compose logs --tail=50)
EOF

cat diagnostic-info.txt
```

### Полезные команды

```bash
# Перезапуск всей системы
docker-compose restart

# Пересоздание контейнеров
docker-compose up -d --force-recreate

# Очистка и перезапуск
docker-compose down
docker-compose up -d

# Просмотр ресурсов
docker stats
```

---

## 📋 Чеклист установки

- [ ] Предустановлен Docker / Docker Desktop
- [ ] Архив скопирован на целевую систему
- [ ] Архив распакован
- [ ] Запущен скрипт установки (install-linux.sh / install-windows.ps1)
- [ ] Образы успешно загружены в Docker
- [ ] Создан и настроен файл .env
- [ ] Указаны корректные MODEL_API_URL, MODEL_API_KEY
- [ ] Указаны корректные GITLAB_URL, GITLAB_TOKEN
- [ ] Система запущена через docker-compose
- [ ] Health check возвращает "healthy"
- [ ] CLI доступны в контейнере (cline --version работает)
- [ ] Подключение к Model API успешно
- [ ] Подключение к GitLab успешно
- [ ] Протестирован тестовый review (опционально)

---

## 📝 Версия пакета

**Версия:** 2.0.0  
**Дата сборки:** 2025-11-06  
**Python:** 3.11  
**Node.js:** 18  
**Docker Base:** nikolaik/python-nodejs:python3.11-nodejs18-slim

---

## 🎉 Готово к работе!

После успешной установки система готова к автоматическому code review через API.

Интегрируйте с вашим CI/CD pipeline или используйте через прямые API вызовы.

**Удачного использования! 🚀**

---

## 📧 Обратная связь

При возникновении проблем:
1. Проверьте логи: `docker-compose logs -f`
2. Проверьте health: `curl http://localhost:8000/api/v1/health`
3. См. детальные инструкции для вашей ОС
4. Соберите диагностическую информацию (см. раздел "Получение помощи")

---

**Copyright © 2025 AI Code Review System**  
**License:** MIT
