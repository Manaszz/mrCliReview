=================================================================
  AI Code Review System - Offline Deployment Package
  Lightweight версия (без предсобранных Docker образов)
=================================================================

Версия пакета: 20251106
Дата создания: Thu Nov  6 10:01:11 AM UTC 2025

ВАЖНО: Этот пакет НЕ содержит предсобранные Docker образы.
Docker образы будут собраны на целевой машине при установке.

ПРЕИМУЩЕСТВА:
- Меньший размер пакета (~100-200 MB вместо ~3 GB)
- Образы собираются с актуальными обновлениями безопасности
- Гибкость при установке

ТРЕБОВАНИЯ НА ЦЕЛЕВОЙ МАШИНЕ:
- Docker + Docker Compose
- Доступ к docker.io и registry.npmjs.org для базовых образов
  (или предварительно загруженные базовые образы)

=================================================================

СОДЕРЖИМОЕ ПАКЕТА:
------------------
1. offline-packages/           - npm пакеты (Cline CLI, Qwen Code CLI)
2. offline-packages/pip/       - Python зависимости (44 файлов)
3. app/, prompts/, rules/      - Исходный код приложения
4. docker-compose.offline.yml  - Docker Compose конфигурация
5. Dockerfile.offline          - Dockerfile для сборки
6. .env.example                - Пример конфигурации
7. install-linux.sh            - Скрипт установки для Linux/VPS
8. install-windows.ps1         - Скрипт установки для Windows
9. docs/                       - Полная документация

=================================================================

БЫСТРАЯ УСТАНОВКА:

=== Linux / VPS ===
1. tar -xzf code-review-offline-lightweight-20251106.tar.gz
2. cd code-review-offline-lightweight-20251106
3. bash install-linux.sh
4. nano .env (настроить MODEL_API_URL, GITLAB_URL, tokens)
5. docker-compose -f docker-compose.offline.yml up -d

=== Windows PC ===
1. Распаковать архив (7-Zip/WinRAR)
2. PowerShell от администратора
3. cd code-review-offline-lightweight-20251106
4. .\install-windows.ps1
5. Настроить .env (откроется автоматически)
6. docker-compose -f docker-compose.offline.yml up -d

=================================================================

ПРОВЕРКА РАБОТЫ:
curl http://localhost:8000/api/v1/health

Ожидаемый ответ:
{
  "status": "healthy",
  "cline_available": true,
  "qwen_available": true
}

=================================================================

ДОКУМЕНТАЦИЯ:
- INSTALL_README.md - Подробная инструкция для пользователей
- docs/WINDOWS_OFFLINE_INSTALL.md - Установка на Windows
- docs/LINUX_VPS_OFFLINE_INSTALL.md - Установка на Linux VPS
- docs/OFFLINE_BUILD.md - Сборка образов
- docs/AIR_GAP_TRANSFER.md - Air-gap развертывание

=================================================================

TROUBLESHOOTING:

1. npm пакеты не установились:
   docker exec -it code-review-api bash
   npm install -g /tmp/npm-packages/cline-*.tgz

2. Не подключается к Model API:
   - Проверьте MODEL_API_URL в .env
   - Для localhost: host.docker.internal (Win) или 172.17.0.1 (Linux)

3. Порт 8000 занят:
   В docker-compose.offline.yml: "8001:8000"

Полный troubleshooting см. в документации.

=================================================================
