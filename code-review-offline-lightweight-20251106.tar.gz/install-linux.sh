#!/bin/bash
set -e

echo "==================================================================="
echo "  AI Code Review System - Установка (Linux/VPS)"
echo "==================================================================="
echo ""

if ! command -v docker &> /dev/null; then
    echo "❌ Docker не найден. Установите Docker:"
    echo "   curl -fsSL https://get.docker.com | sh"
    exit 1
fi

echo "✅ Docker найден"
echo ""

echo "📦 Сборка Docker образов..."
echo "ВАЖНО: Это может занять 10-15 минут"
echo ""

# Скачать базовый образ (если есть интернет) или загрузить из tar
if [ -f base-python-nodejs.tar ]; then
    echo "  → Загрузка базового образа из архива..."
    docker load -i base-python-nodejs.tar
else
    echo "  → Скачивание базового образа..."
    docker pull nikolaik/python-nodejs:python3.11-nodejs18-slim
fi

# Собрать API образ
echo "  → Сборка code-review-api..."
docker-compose -f docker-compose.offline.yml build

if [ ! -f .env ]; then
    echo ""
    echo "⚙️  Создание .env файла..."
    cp .env.example .env
    echo "❗ ВАЖНО: Отредактируйте .env файл:"
    echo "   nano .env"
    echo ""
    echo "Требуемые параметры:"
    echo "  - MODEL_API_URL"
    echo "  - MODEL_API_KEY"
    echo "  - GITLAB_URL"
    echo "  - GITLAB_TOKEN"
fi

echo ""
echo "==================================================================="
echo "✅ Установка завершена!"
echo ""
echo "Следующие шаги:"
echo "  1. Отредактируйте .env: nano .env"
echo "  2. Запустите: docker-compose -f docker-compose.offline.yml up -d"
echo "  3. Проверьте: curl http://localhost:8000/api/v1/health"
echo "==================================================================="
