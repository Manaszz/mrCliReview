# AI Code Review System v2.0

**Мультиагентная система автоматического ревью кода на базе Cline и Qwen Code CLI**

## 🎯 Обзор

Система автоматического code review, использующая CLI инструменты (Cline, Qwen Code) с поддержкой LLM моделей DeepSeek V3.1 Terminus и Qwen3-Coder через OpenAI-совместимый API. Предназначена для интеграции с GitLab и n8n для полной автоматизации процесса ревью merge requests.

### Ключевые особенности

- 🤖 **Два CLI агента**: Cline (DeepSeek V3.1) и Qwen Code (Qwen3-Coder) с гибким переключением
- 🔍 **13 типов проверок**: От обнаружения ошибок до генерации тестов
- 🚀 **Параллельное выполнение**: Множественные инстансы CLI для разных типов ревью
- 📝 **Автоматическая документация**: Javadoc и комментарии коммитятся в исходную ветку
- 🔧 **Умный рефакторинг**: Классификация на significant/minor с созданием отдельных MR
- 📚 **Memory Bank**: Интеграция с контекстом проекта для улучшения качества ревью
- 📎 **Автовстраивание файлов**: Промпты автоматически встраивают referenced файлы
- 🔒 **Minimal GitLab API**: Основная работа через Git CLI, API только для MR
- 🌐 **Confluence rules**: Загрузка правил из Confluence (опционально)
- 🐳 **Docker + K8s**: Готовые конфигурации для развертывания

## 📐 Архитектура развертывания

### Вопрос: Должны ли API и CLI быть на одном сервере?

**Ответ**: Зависит от требований к безопасности и масштабируемости.

#### Вариант 1: Совместное размещение (Рекомендуется для начала)

```
┌─────────────────────────────────────┐
│      Docker Container / K8s Pod     │
│                                     │
│  ┌──────────────┐  ┌─────────────┐ │
│  │  FastAPI     │  │  Cline CLI  │ │
│  │  Review API  │──│  Qwen CLI   │ │
│  └──────────────┘  └─────────────┘ │
│         │                           │
│         │                           │
│  ┌──────▼──────┐                   │
│  │   Git CLI   │                   │
│  └─────────────┘                   │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────┐     ┌──────────────┐
│   Model API     │     │   GitLab     │
│  (DeepSeek/     │     │  (Minimal    │
│   Qwen3)        │     │   API usage) │
└─────────────────┘     └──────────────┘
```

**Преимущества**:
- ✅ Простое развертывание (один контейнер/pod)
- ✅ Низкая латентность (локальное взаимодействие)
- ✅ Проще отладка
- ✅ Нет сетевых задержек между API и CLI

**Недостатки**:
- ❌ Больше ресурсов на один контейнер (Node.js + Python + Git)
- ❌ Сложнее масштабировать отдельно

**Использование**:
- Малые/средние команды (до 100 MR/день)
- Простая инфраструктура
- Быстрый старт

#### Вариант 2: Раздельное размещение (Для Enterprise)

```
┌──────────────────┐      ┌───────────────────────┐
│   Review API     │      │   CLI Workers Pool    │
│   (FastAPI)      │◄────►│  ┌─────────────────┐  │
│                  │      │  │ Worker 1: Cline │  │
│  - API endpoints │      │  └─────────────────┘  │
│  - GitLab API    │      │  ┌─────────────────┐  │
│  - Orchestration │      │  │ Worker 2: Qwen  │  │
└──────────────────┘      │  └─────────────────┘  │
                          │  ┌─────────────────┐  │
                          │  │ Worker 3: Cline │  │
                          │  └─────────────────┘  │
                          └───────────────────────┘
```

**Преимущества**:
- ✅ Независимое масштабирование (больше CLI workers)
- ✅ Изоляция ресурсов
- ✅ Возможность разных версий CLI
- ✅ Graceful degradation (если один worker падает)

**Недостатки**:
- ❌ Сложность архитектуры (нужен message broker: RabbitMQ/Redis)
- ❌ Увеличенная латентность (сетевое взаимодействие)
- ❌ Больше инфраструктурных затрат

**Использование**:
- Крупные команды (>100 MR/день)
- Требуется высокая доступность
- Разные типы review на разных workers

### Как взаимодействуют компоненты?

#### В совместном размещении (текущая реализация):

```python
# FastAPI endpoint
@app.post("/api/v1/review")
async def review(request: ReviewRequest):
    # 1. Клонируем репозиторий через Git CLI
    repo_path = await git_manager.clone_repository(...)
    
    # 2. Вызываем CLI напрямую через subprocess
    # CLI сам определяет changed files через git diff
    process = await asyncio.create_subprocess_exec(
        "cline", "review",
        "--model", "deepseek-v3.1-terminus",
        "--api-base", settings.MODEL_API_URL,
        "--api-key", settings.MODEL_API_KEY,
        cwd=repo_path  # CLI работает внутри репозитория
    )
    
    # 3. Читаем результаты от CLI
    stdout, stderr = await process.communicate()
    result = parse_cli_output(stdout)
    
    # 4. Создаем MR через GitLab API
    await gitlab_service.create_merge_request(...)
    
    # 5. Cleanup
    await git_manager.cleanup_repository(repo_path)
```

**Взаимодействие**:
1. **FastAPI ↔ CLI**: Прямые subprocess вызовы, JSON через stdout/stderr
2. **CLI ↔ Git**: CLI использует локальный `.git` репозиторий
3. **CLI ↔ Model API**: HTTP запросы к OpenAI-compatible endpoint
4. **FastAPI ↔ GitLab**: Минимальные HTTP запросы (create MR, add comment)

#### В раздельном размещении (будущее расширение):

```python
# FastAPI endpoint
@app.post("/api/v1/review")
async def review(request: ReviewRequest):
    # 1. Публикуем задачу в очередь
    task_id = await queue.publish({
        "project_id": request.project_id,
        "mr_iid": request.merge_request_iid,
        "review_types": request.review_types
    })
    
    # 2. Возвращаем task_id клиенту
    return {"task_id": task_id, "status": "queued"}

# CLI Worker
async def worker():
    async for task in queue.consume():
        # Клонирует, выполняет review, возвращает результат
        result = await execute_review(task)
        await queue.publish_result(task.id, result)
```

## 🔍 Поддерживаемые проверки и агенты

### Типы проверок (Review Types)

#### Обязательные проверки
1. **ERROR_DETECTION** - Обнаружение ошибок и багов
   - NullPointerException, IndexOutOfBounds
   - Неправильная обработка исключений
   - Логические ошибки

2. **SECURITY_AUDIT** - Аудит безопасности
   - SQL injection, XSS
   - Небезопасное использование криптографии
   - Уязвимости с CWE-кодами

3. **BEST_PRACTICES** - Соответствие best practices
   - Naming conventions
   - Code organization
   - SOLID principles

4. **UNIT_TEST_COVERAGE** 🆕 - Анализ покрытия тестами
   - Проверка наличия тестов для изменённого кода
   - Автоматическая генерация недостающих тестов
   - Использование проектных `*Base` тест-классов

#### Опциональные проверки
5. **REFACTORING** - Предложения по рефакторингу
   - Упрощение сложного кода
   - Извлечение методов
   - Удаление дублирования

6. **DOCUMENTATION** - Проверка документации
   - Javadoc для public методов
   - Комментарии для сложной логики
   - README обновления

7. **PERFORMANCE** - Оптимизация производительности
   - N+1 queries
   - Неэффективные циклы
   - Кэширование

8. **ARCHITECTURE** - Архитектурные проблемы
   - Нарушение слоёв
   - Циклические зависимости
   - Неправильное использование паттернов

9. **TRANSACTION_MANAGEMENT** - Управление транзакциями
   - Границы транзакций
   - Изоляция данных
   - Распределённые транзакции

10. **CONCURRENCY** - Проблемы многопоточности
    - Race conditions
    - Deadlocks
    - Thread-safety

11. **DATABASE_OPTIMIZATION** - Оптимизация БД
    - Индексы
    - Query performance
    - Schema design

12. **MEMORY_BANK** 🆕 - Интеграция Memory Bank
    - Анализ MR и обновление контекста проекта
    - Автоматическое поддержание актуальности документации
    - Сохранение архитектурных решений

13. **ALL** - Выполнить все проверки

### TODO Агенты (Фаза 2)

#### JIRA Task Matcher 📋
- Проверка соответствия MR требованиям JIRA-задачи
- Оценка полноты реализации
- Обнаружение недостающего функционала
- **Статус**: В разработке

#### Changelog Generator 📝
- Автоматическая генерация CHANGELOG.md
- Анализ commit history
- Следование формату Keep a Changelog
- **Статус**: В разработке

#### Library Updater 🔄
- Обнаружение устаревших зависимостей
- Проверка совместимости через MCP RAG
- Генерация миграционных заметок
- **Статус**: В разработке

> **Примечание**: Детальная документация по обработке ошибок и логированию доступна в [ERROR_HANDLING_RU.md](docs/ERROR_HANDLING_RU.md)

## 📚 Глоссарий документации

### Основная документация

| Документ | Описание | Язык |
|----------|----------|------|
| [README.md](README.md) | Основное описание проекта, быстрый старт | 🇷🇺 RU |
| [PRD_RU.md](docs/PRD_RU.md) | Полный документ требований к продукту | 🇷🇺 RU |
| [PRD.md](docs/PRD.md) | Product Requirements Document | 🇬🇧 EN |
| [SUMMARY.md](SUMMARY.md) | Краткая сводка проекта | 🇷🇺 RU |

### Архитектура и развёртывание

| Документ | Описание | Язык |
|----------|----------|------|
| [ARCHITECTURE_RU.md](docs/ARCHITECTURE_RU.md) | Архитектура системы | 🇷🇺 RU |
| [DEPLOYMENT_GUIDE_RU.md](docs/DEPLOYMENT_GUIDE_RU.md) | Полное руководство по развёртыванию | 🇷🇺 RU |
| [AIR_GAP_TRANSFER.md](docs/AIR_GAP_TRANSFER.md) | Руководство по air-gap передаче для изолированных сред | 🇷🇺 RU |
| [OFFLINE_BUILD.md](docs/OFFLINE_BUILD.md) | Сборка и развёртывание в offline режиме | 🇷🇺 RU |
| [OFFLINE_QUICK_START.md](OFFLINE_QUICK_START.md) | Быстрый старт для offline установки | 🇷🇺 RU |
| [DOCKER_OFFLINE_PROBLEM.md](docs/DOCKER_OFFLINE_PROBLEM.md) | Решение проблем Docker в offline режиме | 🇷🇺 RU |

### Настройка и конфигурация

| Документ | Описание | Язык |
|----------|----------|------|
| [CLI_SETUP.md](docs/CLI_SETUP.md) | Настройка CLI инструментов (Cline, Qwen) | 🇬🇧 EN |
| [RULES_CUSTOMIZATION.md](docs/RULES_CUSTOMIZATION.md) | Кастомизация правил ревью | 🇷🇺 RU |
| [PROMPTS_GUIDE.md](docs/PROMPTS_GUIDE.md) | Руководство по системе промптов | 🇷🇺 RU |
| [SYSTEM_PROMPT_GUIDE.md](docs/SYSTEM_PROMPT_GUIDE.md) | Руководство по системному промпту | 🇬🇧 EN |
| [NEW_REVIEW_TYPES.md](docs/NEW_REVIEW_TYPES.md) | Документация новых типов ревью (UNIT_TEST_COVERAGE, MEMORY_BANK) | 🇷🇺 RU |
| [CLI_PROMPT_ANALYSIS.md](docs/CLI_PROMPT_ANALYSIS.md) | Анализ стабильности CLI промптов и рекомендации | 🇷🇺 RU |
| [PROMPT_IMPROVEMENTS_2025-11-05.md](docs/PROMPT_IMPROVEMENTS_2025-11-05.md) | Реализованные улучшения промптов и валидации | 🇬🇧 EN |

### CLI агенты и ответственность

| Документ | Описание | Язык |
|----------|----------|------|
| [CLI_RESPONSIBILITY_QUICK.md](CLI_RESPONSIBILITY_QUICK.md) | Быстрая справка по разделению ответственности | ru RU |
| [CLI_RESPONSIBILITY_SEPARATION.md](docs/CLI_RESPONSIBILITY_SEPARATION.md) | Разделение ответственностей CLI и FastAPI | ru RU |
| [CLI_ACCESS_QUICK.md](CLI_ACCESS_QUICK.md) | Быстрая справка по CLI доступу | ru RU |

### Интеграции и workflow

| Документ | Описание | Язык |
|----------|----------|------|
| [N8N_WORKFLOW.md](docs/N8N_WORKFLOW.md) | Интеграция с n8n workflow | 🇬🇧 EN |
| [ERROR_HANDLING_RU.md](docs/ERROR_HANDLING_RU.md) | Обработка ошибок и мониторинг | 🇷🇺 RU |

### Примеры и шаблоны

| Файл | Описание |
|------|----------|
| [env.example.annotated](env.example.annotated) | Аннотированный пример .env файла |
| [docker-compose.yml](docker-compose.yml) | Docker Compose конфигурация для стандартного развёртывания |
| [docker-compose.offline.yml](docker-compose.offline.yml) | Docker Compose конфигурация для offline режима |
| [deployment/kubernetes/](deployment/kubernetes/) | Kubernetes манифесты для продакшн развёртывания |

### Правила и промпты

| Директория | Описание |
|------------|----------|
| [rules/java-spring-boot/](rules/java-spring-boot/) | Правила ревью по умолчанию для Java Spring Boot |
| [prompts/cline/](prompts/cline/) | Промпты для Cline CLI агента |
| [prompts/qwen/](prompts/qwen/) | Промпты для Qwen Code CLI агента |
| [prompts/additional/](prompts/additional/) | Дополнительные специализированные промпты |
| [prompts/todo/](prompts/todo/) | Промпты для будущих TODO функций |

### Исследования

| Документ | Описание |
|----------|----------|
| [research/Qwen Code для ревью merge requests_ полный анализ.md](research/Qwen%20Code%20для%20ревью%20merge%20requests_%20полный%20анализ.md) | Анализ Qwen Code для MR ревью |
| [research/Возможно ли реализовать, чтоб self-hosted n8n на сервере управлял CLI агентом.md](research/Возможно%20ли%20реализовать,%20чтоб%20self-hoted%20n8n%20%20на%20с.md) | Исследование self-hosted n8n |

---

## 📖 Быстрые ссылки

### Для начала работы
1. 🚀 [README.md](README.md) - Старт здесь
2. 📦 [OFFLINE_QUICK_START.md](OFFLINE_QUICK_START.md) - Offline установка
3. 🐳 [DEPLOYMENT_GUIDE_RU.md](docs/DEPLOYMENT_GUIDE_RU.md) - Полное развёртывание

### Для настройки
1. ⚙️ [CLI_SETUP.md](docs/CLI_SETUP.md) - Настройка CLI
2. 📝 [RULES_CUSTOMIZATION.md](docs/RULES_CUSTOMIZATION.md) - Свои правила
3. 💬 [PROMPTS_GUIDE.md](docs/PROMPTS_GUIDE.md) - Настройка промптов

### Для понимания системы
1. 🏗️ [ARCHITECTURE_RU.md](docs/ARCHITECTURE_RU.md) - Архитектура
2. 📋 [PRD_RU.md](docs/PRD_RU.md) - Полное описание продукта
3. 🤖 [NEW_REVIEW_TYPES.md](docs/NEW_REVIEW_TYPES.md) - Новые возможности

### Для production
1. ☸️ [deployment/kubernetes/](deployment/kubernetes/) - Kubernetes манифесты
2. 🔒 [AIR_GAP_TRANSFER.md](docs/AIR_GAP_TRANSFER.md) - Изолированные среды
3. 🚨 [ERROR_HANDLING_RU.md](docs/ERROR_HANDLING_RU.md) - Обработка ошибок

## 🚀 Быстрый старт

### Docker Compose (Рекомендуется)

```bash
# 1. Клонировать репозиторий
git clone <repo-url>
cd mrCliReview

# 2. Создать .env файл (скопировать содержимое из README ниже)
cat > .env << 'EOF'
MODEL_API_URL=https://your-api.example.com/v1
MODEL_API_KEY=your-api-key
DEEPSEEK_MODEL_NAME=deepseek-v3.1-terminus
QWEN3_MODEL_NAME=qwen3-coder-32b
GITLAB_URL=https://gitlab.example.com
GITLAB_TOKEN=your-gitlab-token
DEFAULT_CLI_AGENT=CLINE
LOG_LEVEL=INFO
EOF

# 3. Запустить
docker-compose up -d

# 4. Проверить
curl http://localhost:8000/health
curl http://localhost:8000/api/v1/health
```

### Kubernetes

```bash
cd deployment/kubernetes

# 1. Настроить secrets
kubectl apply -f secret.yaml

# 2. Настроить config
kubectl apply -f configmap.yaml

# 3. Deploy
kubectl apply -f namespace.yaml
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f ingress.yaml
```

## 📊 API Endpoints

```
GET  /                     - Service info
GET  /health               - Simple health check
GET  /api/v1/health        - Detailed health check
POST /api/v1/review        - Execute code review
POST /api/v1/validate-mr   - Validate MR (n8n integration)
```

## 🤝 Contributing

См. [CONTRIBUTING.md](CONTRIBUTING.md)

## 📄 License

MIT License
