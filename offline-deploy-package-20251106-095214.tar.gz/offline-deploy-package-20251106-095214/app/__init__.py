"""Qwen Code Review Service"""

__version__ = "1.0.0"


